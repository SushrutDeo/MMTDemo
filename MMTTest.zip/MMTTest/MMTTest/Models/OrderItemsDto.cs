﻿namespace MMTTest.Models
{
	public class OrderItemsDto
	{
		public string product { get; set; }

		public int? quantity { get; set; }

		public decimal? priceEach { get; set; }
	}
}