﻿using System;
using System.Collections.Generic;

namespace MMTTest.Models
{
	public class OrderDto
	{
		public OrderDto()
		{
			orderItems = new List<OrderItemsDto>();
		}

		public int orderNumber { get; set; }

		public DateTime? orderDate { get; set; }

		public string deliveryAddress { get; set; }

		public ICollection<OrderItemsDto> orderItems { get; set; }

		public DateTime? deliveryExpected { get; set; }
	}
}