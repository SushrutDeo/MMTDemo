﻿namespace MMTTest.Models
{
	public class OrderDetailsDto
	{
		public CustomerDto customer { get; set; }

		public OrderDto order { get; set; }
	}
}