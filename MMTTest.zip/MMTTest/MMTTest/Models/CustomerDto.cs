﻿namespace MMTTest.Models
{
	public class CustomerDto
	{
		public string firstName { get; set; }

		public string lastName { get; set; }
	}
}