﻿namespace MMTTest.Models
{
	public class GetOrderDetailsRequestModel
	{
		public string Email { get; set; }

		public string CustomerId { get; set; }
	}
}