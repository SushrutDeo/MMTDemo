﻿using MMTTest.Models;
using MMTTest.Services.Interfaces;

using System;
using System.Web.Http;

namespace MMTTest.Controllers
{
	public class OrdersController : ApiController
	{
		private readonly IRetrieveCustomerOrderDetailsService m_retrieve_customer_order_details_service;

		public OrdersController( IRetrieveCustomerOrderDetailsService retrieveCustomerOrderDetailsService )
		{
			m_retrieve_customer_order_details_service = retrieveCustomerOrderDetailsService;
		}

		[HttpPost]
		public IHttpActionResult GetOrderDetails( GetOrderDetailsRequestModel getOrderDetailsRequestModel )
		{
			IHttpActionResult httpActionResult = null;

			try
			{

				CustomerDetails customerDetails = m_retrieve_customer_order_details_service.GetCustomerDetails( getOrderDetailsRequestModel.Email );

				if ( customerDetails == null )
				{
					httpActionResult = NotFound();
				}
				else
				{
					OrderDetailsDto orderDetailsDto = m_retrieve_customer_order_details_service
						.GetOrderDetails( getOrderDetailsRequestModel.Email, getOrderDetailsRequestModel.CustomerId );

					if ( orderDetailsDto != null )
					{
						return Ok( orderDetailsDto );
					}
					else
					{
						return Ok( customerDetails );
					}
				}
			}
			catch ( Exception ex )
			{
				ex.ToString(); // Do something to log the error
				httpActionResult = InternalServerError();
			}

			return httpActionResult;
		}
	}
}
