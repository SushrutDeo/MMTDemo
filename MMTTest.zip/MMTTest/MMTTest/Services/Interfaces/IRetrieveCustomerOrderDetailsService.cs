﻿using MMTTest.Models;

namespace MMTTest.Services.Interfaces
{
	public interface IRetrieveCustomerOrderDetailsService
	{
		CustomerDetails GetCustomerDetails( string email );

		OrderDetailsDto GetOrderDetails( string email, string customerId );
	}
}
