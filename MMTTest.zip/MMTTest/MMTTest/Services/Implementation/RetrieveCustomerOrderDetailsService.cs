﻿using MMTTest.Models;
using MMTTest.Services.Interfaces;

using Newtonsoft.Json;

using System;
using System.Data.Entity;
using System.Linq;
using System.Net.Http;
using System.Web.Configuration;

namespace MMTTest.Services.Implementation
{
	public class RetrieveCustomerOrderDetailsService : IRetrieveCustomerOrderDetailsService
	{
		private readonly SSE_TestEntities m_entities;

		public RetrieveCustomerOrderDetailsService( SSE_TestEntities sSE_TestEntities )
		{
			m_entities = sSE_TestEntities;
		}

		public CustomerDetails GetCustomerDetails( string email )
		{
			CustomerDetails customerDetails = null;

			string customerDetailsApi = WebConfigurationManager.AppSettings[ "CustomerDetailsApi" ];

			string apiKey = WebConfigurationManager.AppSettings[ "ApiKey" ];

			string customerDetailsApiCompletePath = customerDetailsApi + $"?email={email}&code={apiKey}";

			Uri uri = new Uri( customerDetailsApiCompletePath );

			HttpClient httpClient = new HttpClient();

			HttpResponseMessage response = httpClient.GetAsync( uri ).Result;

			if ( response.IsSuccessStatusCode )
			{
				string content = response.Content.ReadAsStringAsync().Result;

				customerDetails = JsonConvert.DeserializeObject<CustomerDetails>( content );
			}

			return customerDetails;
		}

		public OrderDetailsDto GetOrderDetails( string email, string customerId )
		{
			CustomerDetails customerDetails = GetCustomerDetails( email );

			OrderDetailsDto orderDetailsDto = null;

			string address = "";

			if ( customerDetails != null && customerDetails.customerId == customerId )
			{
				orderDetailsDto.customer.firstName = customerDetails.firstName;
				orderDetailsDto.customer.lastName = customerDetails.lastName;

				var orders = m_entities.ORDERS.Where( x => x.CUSTOMERID == customerId ).Include( x => x.ORDERITEMS )
					.OrderByDescending( x => x.ORDERDATE );

				ORDER recentOrder = null;

				if ( orders != null && orders.Count() > 0 )
				{
					recentOrder = orders.FirstOrDefault();

					orderDetailsDto = new OrderDetailsDto();

					address = $"{customerDetails.houseNumber}, {customerDetails.street}, {customerDetails.town}, {customerDetails.postcode}";

					orderDetailsDto.order.orderNumber = recentOrder.ORDERID;
					orderDetailsDto.order.orderDate = recentOrder.ORDERDATE;
					orderDetailsDto.order.deliveryAddress = address;
					orderDetailsDto.order.deliveryExpected = recentOrder.DELIVERYEXPECTED;

					if ( recentOrder.ORDERITEMS != null && recentOrder.ORDERITEMS.Count > 0 )
					{
						foreach ( var item in recentOrder.ORDERITEMS )
						{
							var orderItemDto = new OrderItemsDto();

							if ( recentOrder.CONTAINSGIFT.HasValue && recentOrder.CONTAINSGIFT.Value == true )
							{
								orderItemDto.product = "contains a gift";
							}
							else
							{
								orderItemDto.product = item.PRODUCT.PRODUCTNAME;
							}

							orderItemDto.quantity = item.QUANTITY;
							orderItemDto.priceEach = item.PRICE;

							orderDetailsDto.order.orderItems.Add( orderItemDto );
						}
					}
				}
			}

			return orderDetailsDto;
		}
	}
}